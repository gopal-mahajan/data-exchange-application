package com.data.kaveri.dataexchange.exception;

public class InvalidInput extends Exception {
    public InvalidInput(String msg) {
        super(msg);
    }
}
